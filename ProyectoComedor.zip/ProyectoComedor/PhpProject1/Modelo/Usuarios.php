<?php

 class usuarios{

	public $usuario;
	function get_usuario(){
		return $this->usuario;
	}
	function set_usuario($usuario){
		$this->usuario = $usuario;
	}
	public $contrasena;
	function get_contrasena(){
		return $this->contrasena;
	}
	function set_contrasena($contrasena){
		$this->contrasena = $contrasena;
	}
	public $privilegios;
	function get_privilegios(){
		return $this->privilegio;
	}
	function set_privilegios($privilegios){
		$this->privilegios = $privilegio;
	}
 }


