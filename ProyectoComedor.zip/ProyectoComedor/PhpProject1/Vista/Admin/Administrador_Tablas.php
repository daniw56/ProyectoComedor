<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Tablas</title>
	<!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

        <!-- Latest compiled and minified JavaScript -->
        <link href="../../css/style_navbar.css" rel="stylesheet" type="text/css"/>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body>
	<div class="container">
		<header>
			<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-1">
							<span class="sr-only">Menú</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<!-- Poner icono aqui-->
					</div>

					<div class="collapsed navbar-collapse" id="navbar-1">
						<ul class="nav navbar-nav">
							<li class=""><a href="Administrador_Main.php" id="titulo">Vedruna Comedor</a></li>
							<li class=""><a href="Administrador_Calendario.php"><span class="glyphicon glyphicon-calendar"></span>Fecha Actual</a></li>											
						</ul>
						

						<ul class="nav navbar-nav navbar-right">							
							<li class="active"><a href=""><span class="glyphicon glyphicon-folder-open"></span></a></li>
							<li class=""><a href="Administrador_Perfil.php"><span class="glyphicon glyphicon-user"></span></a></li>
							
						</ul>
					</div>
				</div>
			</nav>
		</header>
	</div>		

	<div class="btn-group ">		
		<button class="btn btn-primary" data-toggle="modal"  data-target="#add_admin">Admin</button>
		<button class="btn btn-primary" data-toggle="modal"  data-target="#add_profe">Profesor</button>
		<button class="btn btn-primary" data-toggle="modal"  data-target="#add_dietista">Dietista</button>
		<button class="btn btn-primary" data-toggle="modal"  data-target="#add_alumno">Alumno</button>
	</div>

	<div>
		<table>
			<thread>
				<tr>
					<th><button class="btn btn-info" data-toggle="modal"  data-target="#add_admin">Añadir Evento</button></th>
					<th>Lista Usuarios</th>
				</tr>
			</thread>
			<tbody>
				<tr>
					<td>Nombre</td>
					<td>Apellido</td>
					<td>2Apellido</td>
					<td>Username</td>
					
					<td>Password</td>
					<td>Permisos</td>
					<td>Modificar</td>
					<td>Eliminar</td>
				</tr>
				<?php
					include("../../Controlador/conexion.php");
					$query="SELECT * FROM admins_tb";
					$resultado= $conexion->query($query);
					while($row=$resultado->fech-asoc()){
				?>
				<tr>
					<td><?php echo $row['nombre_adm']; ?></td>
					<td><?php echo $row['apel1_adm']; ?></td>
					<td><?php echo $row['apel2_adm']; ?></td>
					<td><?php echo $row['username_adm']; ?></td>
					<td><?php echo $row['password_adm']; ?></td>
					<td><?php echo $row['permisos_adm']; ?></td>
					<td><a href="Administrador_Tablas.php?username_adm=<?php echo $row['username_adm'] ?>" 	data-toggle="modal" data-target="#upd_admin">Modificar</a></td>
                                        <td><a href="../../Controlador/eliminar_adm.php?username_adm=<?php echo $row['username_adm']; ?>">Eliminar</a></td>
				</tr>
				<?php
					}
				?>
			</tbody>				
		</table>
	</div>	
	<div class="container">
		<div class="modal fade" id="add_admin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4>Agregar nuevo Admin</h4>
					</div>
					<div class="modal-body">
						<form action="operaciones_tablas.php" method="post">
							<label for="from">Nombre</label>
							<div class="input-group date" id="from">
								<input type="text" name="from" class="form-control" readonly/>			
							</div>
							<br>

							<label for="to">Apellido</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Apellido 2</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Nombre Usuario</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Contraseña</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="Password" name="to" class="form-control" readonly/>
							</div>
							<br>
							
							<label for="to">Permisos</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" value="1" disabled name="to" class="form-control" readonly/>
							</div>
							<br>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i>Cancelar</button>
						<button type="submit" class="btn btn-success" ><i class="fa fa-check"></i>Agregar</button>
					</div>					
				</div>				
			</div>
		</div>
	</div>
	<div class="container">
		<div class="modal fade" id="upd_admin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
			<div class="modal-dialog">
				<div class="modal-content">
				
					<div class="modal-header">
						<h4>Modificar Admin</h4>
					</div>
					<div class="modal-body">
						<form action="modificar_adm.php?<?php echo $row['username_adm']; ?>" method="POST">
							<?php 
								$id=$_REQUEST['username_adm'];
								include("conexion.php");

								$query="SELECT * FROM admins_tb WHERE username_adm='$id'";
								$resultado= $conexion->query($query);
								$row=$resultado->fetch-assoc();
							?>
							<label for="from">Nombre</label>
							<div class="input-group date" id="from">
								<input value="<?php echo $row['nombre_adm']; ?>" type="text" name="from" class="form-control" readonly/>			
							</div>
							<br>

							<label for="to">Apellido</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['apel1_adm']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Apellido 2</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['apel2_adm']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Nombre Usuario</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['username_adm']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Contraseña</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['password_adm']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>
							
							<label for="to">Permisos</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" value="1" disabled name="to" class="form-control" readonly/>
							</div>
							<br>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i>Cancelar</button>
						<button type="submit" class="btn btn-success" ><i class="fa fa-check"></i>Modificar</button>
					</div>					
				</div>				
			</div>
		</div>
	</div>
	<div>
		<table>
			<thread>
				<tr>
					<th><button class="btn btn-info" data-toggle="modal"  data-target="#add_profe">Añadir Evento</button></th>
					<th>Lista Profesores</th>
				</tr>
			</thread>
			<tbody>
				<tr>
					<td>Nombre</td>
					<td>Apellido</td>
					<td>2Apellido</td>
					<td>Username</td>
					
					<td>Password</td>
					<td>Permisos</td>
					<td>Modificar</td>
					<td>Eliminar</td>
				</tr>
				<?php
					include("conexion.php");
					$query="SELECT * FROM profesor_tb";
					$resultado= $conexion->query($query);
					while($row=$resultado->fech-asoc()){
				?>
					<tr>
						<td><?php echo $row['nombre_prf']; ?></td>
						<td><?php echo $row['apel1_prf']; ?></td>
						<td><?php echo $row['apel2_prf']; ?></td>
						<td><?php echo $row['username_prf']; ?></td>
						<td><?php echo $row['password_prf']; ?></td>
						<td><?php echo $row['permisos_prf']; ?></td>
						<td><a href="Administrador_Tablas.php?username_prf=<?php echo $row['username_prf'] ?>" data-toggle="modal" data-target="#upd_profe">Modificar</a></td>
						<td><a href="eliminar_prf.php?username_prf=<?php echo $row['username_prf']; ?>">Eliminar</a></td>
					</tr>
				<?php
					}
				?>
			</tbody>				
		</table>
	</div>
	<div class="container">
		<div class="modal fade" id="add_profe" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4>Agregar nuevo Profesor</h4>
					</div>
					<div class="modal-body">
						<form action="operaciones_tablas.php" method="post">
							<label for="from">Nombre</label>
							<div class="input-group date" id="from">
								<input type="text" name="from" class="form-control" readonly/>			
							</div>
							<br>

							<label for="to">Apellido</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Apellido 2</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Nombre Usuario</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Contraseña</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="Password" name="to" class="form-control" readonly/>
							</div>
							<br>
							
							<label for="to">Permisos</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" value="2" disabled name="to" class="form-control" readonly/>
							</div>
							<br>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i>Cancelar</button>
						<button type="submit" class="btn btn-success" ><i class="fa fa-check"></i>Agregar</button>
					</div>					
				</div>				
			</div>
		</div>
	</div>
	<div class="container">
		<div class="modal fade" id="upd_profe" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
			<div class="modal-dialog">
				<div class="modal-content">
				
					<div class="modal-header">
						<h4>Modificar Admin</h4>
					</div>
					<div class="modal-body">
						<form action="modificar_prf.php?<?php echo $row['username_prf']; ?>" method="POST">
							<?php 
								$id=$_REQUEST['username_prf'];
								include("conexion.php");

								$query="SELECT * FROM profesor_tb WHERE username_prf='$id'";
								$resultado= $conexion->query($query);
								$row=$resultado->fetch-assoc();
							?>
							<label for="from">Nombre</label>
							<div class="input-group date" id="from">
								<input value="<?php echo $row['nombre_prf']; ?>" type="text" name="from" class="form-control" readonly/>			
							</div>
							<br>

							<label for="to">Apellido</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['apel1_prf']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Apellido 2</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['apel2_prf']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Nombre Usuario</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['username_prf']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Contraseña</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['password_prf']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>
							
							<label for="to">Permisos</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" value="2" disabled name="to" class="form-control" readonly/>
							</div>
							<br>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i>Cancelar</button>
						<button type="submit" class="btn btn-success" ><i class="fa fa-check"></i>Modificar</button>
					</div>					
				</div>				
			</div>
		</div>
	</div>
	<div>
		<table>
			<thread>
				<tr>
					<th><button class="btn btn-info" data-toggle="modal"  data-target="#add_dietista">Añadir</button></th>
					<th>Lista Dietista</th>
				</tr>
			</thread>
			<tbody>
				<tr>
					<td>Nombre</td>
					<td>Apellido</td>
					<td>2Apellido</td>
					<td>Username</td>
					
					<td>Password</td>
					<td>Permisos</td>
					<td>Modificar</td>
					<td>Eliminar</td>
				</tr>
				<?php
					include("conexion.php");
					$query="SELECT * FROM dietetica_tb";
					$resultado= $conexion->query($query);
					while($row=$resultado->fech-asoc()){
				?>
					<tr>
						<td><?php echo $row['nombre_dti']; ?></td>
						<td><?php echo $row['apel1_dti']; ?></td>
						<td><?php echo $row['apel2_dti']; ?></td>
						<td><?php echo $row['username_dti']; ?></td>
						<td><?php echo $row['password_dti']; ?></td>
						<td><?php echo $row['permisos_dti']; ?></td>
						<td><a href="Administrador_Tablas.php?username_dti=<?php echo $row['username_dti'] ?>" data-toggle="modal" data-target="#upd_dietista">Modificar</a></td>
						<td><a href="eliminar_dti.php?username_dti=<?php echo $row['username_dti']; ?>">Eliminar</a></td>
					</tr>
				<?php
					}
				?>
			</tbody>				
		</table>
	</div>
	<div class="container">
		<div class="modal fade" id="add_profe" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4>Agregar nuevo Profesor</h4>
					</div>
					<div class="modal-body">
						<form action="insert_dietista.php" method="post">
							<label for="from">Nombre</label>
							<div class="input-group date" id="from">
								<input type="text" name="from" class="form-control" readonly/>			
							</div>
							<br>

							<label for="to">Apellido</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Apellido 2</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Nombre Usuario</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Contraseña</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="Password" name="to" class="form-control" readonly/>
							</div>
							<br>
							
							<label for="to">Permisos</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" value="3" disabled name="to" class="form-control" readonly/>
							</div>
							<br>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i>Cancelar</button>
						<button type="submit" class="btn btn-success" ><i class="fa fa-check"></i>Agregar</button>
					</div>					
				</div>				
			</div>
		</div>
	</div>
	<div class="container">
		<div class="modal fade" id="upd_dietista" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4>Modificar Admin</h4>
					</div>
					<div class="modal-body">
						<form action="modificar_dti.php?<?php echo $row['username_dti']; ?>" method="POST">
							<?php 
								$id=$_REQUEST['username_dti'];
								include("conexion.php");

								$query="SELECT * FROM dietetica_tb WHERE username_dti='$id'";
								$resultado= $conexion->query($query);
								$row=$resultado->fetch-assoc();
							?>
							<label for="from">Nombre</label>
							<div class="input-group date" id="from">
								<input value="<?php echo $row['nombre_dti']; ?>" type="text" name="from" class="form-control" readonly/>			
							</div>
							<br>

							<label for="to">Apellido</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['apel1_dti']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Apellido 2</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['apel2_dti']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Nombre Usuario</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['username_dti']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Contraseña</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['password_dti']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>
							
							<label for="to">Permisos</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" value="3" disabled name="to" class="form-control" readonly/>
							</div>
							<br>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i>Cancelar</button>
						<button type="submit" class="btn btn-success" ><i class="fa fa-check"></i>Modificar</button>
					</div>					
				</div>				
			</div>
		</div>
	</div>
	<div>
		<table>
			<thread>
				<tr>
					<th><button class="btn btn-info" data-toggle="modal"  data-target="#add_alumno">Añadir</button></th>
					<th>Lista Alumnos</th>
				</tr>
			</thread>
			<tbody>
				<tr>
					<td>Nombre</td>
					<td>Apellido</td>
					<td>2Apellido</td>
					<td>Curso</td>
					<td>Username</td>
					<td>Password</td>
					<td>Permisos</td>
					<td>Modificar</td>
					<td>Eliminar</td>
				</tr>
				<?php
					include("conexion.php");
					$query="SELECT * FROM alumno_tb";
					$resultado= $conexion->query($query);
					while($row=$resultado->fech-asoc()){
				?>
					<tr>
						<td><?php echo $row['nombre_al']; ?></td>
						<td><?php echo $row['apel1_al']; ?></td>
						<td><?php echo $row['apel2_al']; ?></td>
						<td><?php echo $row['curso']; ?></td>
						<td><?php echo $row['username_al']; ?></td>
						<td><?php echo $row['password_al']; ?></td>
						<td><?php echo $row['permisos_al']; ?></td>
						<td><a href="Administrador_Tablas.php?username_al=<?php echo $row['username_al'] ?>" data-toggle="modal" data-target="#upd_alumno">Modificar</a></td>
						<td><a href="eliminar_alumno.php?username_al=<?php echo $row['username_al']; ?>">Eliminar</a></td>
					</tr>
				<?php
					}
				?>
			</tbody>				
		</table>
	</div>
	<div class="container">
		<div class="modal fade" id="add_alumno" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4>Agregar nuevo Alumno</h4>
					</div>
					<div class="modal-body">
						<form action="insert_alumno.php" method="post">
							<label for="from">Nombre</label>
							<div class="input-group date" id="from">
								<input type="text" name="from" class="form-control" readonly/>			
							</div>
							<br>

							<label for="to">Apellido</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Apellido 2</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Curso</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Nombre Usuario</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Contraseña</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="Password" name="to" class="form-control" readonly/>
							</div>
							<br>
							
							<label for="to">Permisos</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" value="1" disabled name="to" class="form-control" readonly/>
							</div>
							<br>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i>Cancelar</button>
						<button type="submit" class="btn btn-success" ><i class="fa fa-check"></i>Agregar</button>
					</div>					
				</div>				
			</div>
		</div>
	</div>
	<div class="container">
		<div class="modal fade" id="upd_alumno" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
			<div class="modal-dialog">
				<div class="modal-content">
				
					<div class="modal-header">
						<h4>Modificar Admin</h4>
					</div>
					<div class="modal-body">
						<form action="modificar_al.php?<?php echo $row['username_al']; ?>" method="POST">
							<?php 
								$id=$_REQUEST['username_al'];
								include("conexion.php");

								$query="SELECT * FROM alumno_tb WHERE username_al='$id'";
								$resultado= $conexion->query($query);
								$row=$resultado->fetch-assoc();
							?>
							<label for="from">Nombre</label>
							<div class="input-group date" id="from">
								<input value="<?php echo $row['nombre_ul']; ?>" type="text" name="from" class="form-control" readonly/>			
							</div>
							<br>

							<label for="to">Apellido</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['apel1_ul']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Apellido 2</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['apel2_ul']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Curso</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['curso']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Nombre Usuario</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['username_ul']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>

							<label for="to">Contraseña</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input value="<?php echo $row['password_ul']; ?>" type="text" name="to" class="form-control" readonly/>
							</div>
							<br>
							
							<label for="to">Permisos</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" value="4" disabled name="to" class="form-control" readonly/>
							</div>
							<br>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i>Cancelar</button>
						<button type="submit" class="btn btn-success" ><i class="fa fa-check"></i>Modificar</button>
					</div>					
				</div>				
			</div>
		</div>
	</div>


</body>
</html>