<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Calendario</title>
	<!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body>
	<div class="container">
		<header>
			<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-1">
							<span class="sr-only">Menú</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<!-- Poner icono aqui-->
					</div>

					<div class="collapsed navbar-collapse" id="navbar-1">
						<ul class="nav navbar-nav">
							<li class=""><a href="Administrador_Main.php" id="titulo">Vedruna Comedor</a></li>
							<li class="active"><a href=""><span class="glyphicon glyphicon-calendar"></span>Fecha Actual</a></li>											
						</ul>					

						<ul class="nav navbar-nav navbar-right">							
							<li id="nuevo" class="dropdown">
								<a class="dropdown-toggle" data-toggle="dropdown" role="button" href="">
								Nuevo! <span class="caret"></span>
								</a>
								<ul class="dropdown-menu">
									<li><a href="">Menú</a></li>
									<li><a href="">Alimento</a></li>
									<li class="divider"></li>
									<li><a href="">Alumno</a></li>
									<li><a href="">Profesor</a></li>
									<li><a href="">Dietista</a></li>
									<li><a href="">Administrador</a></li>
								</ul>
							</li>
                                                        <li class=""><a href="Administrador_Tablas.php"><span class="glyphicon glyphicon-folder-open"></span></a></li>
                                                        <li class=""><a href="Administrador_Perfil.php"><span class="glyphicon glyphicon-user"></span></a></li>
							
						</ul>
					</div>
				</div>
			</nav>
		</header>
	</div>
	
	<div class="container">
		<div class="row">
			<div class="pull-left form-inline">
				<div class="btn-group">
					<button class="btn btn-primary"><< Anterior</button>
					<button class="btn btn-primary">Hoy</button>
					<button class="btn btn-primary">Siguiente >></button>
				</div>
				<div class="btn-group">
					<button class="btn btn-warning">Año</button>
					<button class="btn btn-warning active">Mes</button>
					<button class="btn btn-warning">Semana</button>
					<button class="btn btn-warning">Dia</button>
				</div>
			</div>
			<div class="pull-right form-inline">
				<button class="btn btn-info" data-toggle="modal"  data-target="#add_evento">Añadir Evento</button>
			</div>
		</div>
		<hr>

		<div class="row">
			<div id="calendar">
			</div>
			<br><br>
		</div>


		<div class="modal fade" id="events-modal">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-body" style="height: 400px">
						<p>One fine Body&hellip;</p>
					</div>
					<div>
						<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
					</div>
				</div>
			</div>
		</div>
	</div>
    <script type="text/javascript">
        (function($){
                //creamos la fecha actual
                var date = new Date();
                var yyyy = date.getFullYear().toString();
                var mm = (date.getMonth()+1).toString().length == 1 ? "0"+(date.getMonth()+1).toString() : (date.getMonth()+1).toString();
                var dd  = (date.getDate()).toString().length == 1 ? "0"+(date.getDate()).toString() : (date.getDate()).toString();

                //establecemos los valores del calendario
                var options = {

                    // definimos que los eventos se mostraran en ventana modal
                        modal: '#events-modal', 

                        // dentro de un iframe
                        modal_type:'iframe',    

                        //obtenemos los eventos de la base de datos
                        events_source: 'obtener_eventos.php', 

                        // mostramos el calendario en el mes
                        view: 'month',             

                        // y dia actual
                        day: yyyy+"-"+mm+"-"+dd,   


                        // definimos el idioma por defecto
                        language: 'es-ES', 

                        //Template de nuestro calendario
                        tmpl_path: '<?=$base_url?>tmpls/', 
                        tmpl_cache: false,


                        // Hora de inicio
                        time_start: '08:00', 

                        // y Hora final de cada dia
                        time_end: '22:00',   

                        // intervalo de tiempo entre las hora, en este caso son 30 minutos
                        time_split: '30',    

                        // Definimos un ancho del 100% a nuestro calendario
                        width: '100%', 

                        onAfterEventsLoad: function(events)
                        {
                                if(!events)
                                {
                                        return;
                                }
                                var list = $('#eventlist');
                                list.html('');

                                $.each(events, function(key, val)
                                {
                                        $(document.createElement('li'))
                                                .html('<a href="' + val.url + '">' + val.title + '</a>')
                                                .appendTo(list);
                                });
                        },
                        onAfterViewLoad: function(view)
                        {
                                $('.page-header h2').text(this.getTitle());
                                $('.btn-group button').removeClass('active');
                                $('button[data-calendar-view="' + view + '"]').addClass('active');
                        },
                        classes: {
                                months: {
                                        general: 'label'
                                }
                        }
                };


                // id del div donde se mostrara el calendario
                var calendar = $('#calendar').calendar(options); 

                $('.btn-group button[data-calendar-nav]').each(function()
                {
                        var $this = $(this);
                        $this.click(function()
                        {
                                calendar.navigate($this.data('calendar-nav'));
                        });
                });

                $('.btn-group button[data-calendar-view]').each(function()
                {
                        var $this = $(this);
                        $this.click(function()
                        {
                                calendar.view($this.data('calendar-view'));
                        });
                });

                $('#first_day').change(function()
                {
                        var value = $(this).val();
                        value = value.length ? parseInt(value) : null;
                        calendar.setOptions({first_day: value});
                        calendar.view();
                });
        }(jQuery));
    </script>
	<div class="container">
		<div class="modal fade" id="add_evento" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4>Agregar nuevo evento</h4>
					</div>
					<div class="modal-body">
						<form action="../calendario/index2.php" method="post">
							<label for="from">Inicio</label>
							<div class="input-group date" id="from">
								<input type="text" name="from" class="form-control" readonly/>
								<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
							</div>
							<br>

							<label for="to">Final</label>
							<div class="input-group date" data-provide="datepicker" id="to">
								 <input type="text" name="to" class="form-control" readonly/>
								 <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
							</div>
							<br>

							<label for="tipo">Tipo de Evento</label>
							<select class="form-control" name="class" id="tipo">
								<option value="event-info">Informacion</option>
								<option value="event-success">Exito</option>
								<option value="event-important">Inportante</option>
								<option value="event-warning">Advertencia</option>
								<option value="event-special">Especial</option>
							</select>
							<br>

							<label for="title">Título</label>
							<input type="text" required autocomplete="off" name="title" class="form-control" id="title" placeholder="Introduce un título">
							<br>

							<label for="body">Evento</label>
							<textarea id="body" name="event" required class="form-control" rows="3"></textarea>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i>Cancelar</button>
						<button type="submit" class="btn btn-success" ><i class="fa fa-check"></i>Agregar</button>
					</div>
					<script type="text/javascript">
		                $(function () {
		                    $('#from').datetimepicker({
		                        language: 'es',
		                        minDate: new Date()
		                    });
		                    $('#to').datetimepicker({
		                        language: 'es',
		                        minDate: new Date()
		                    });

		                });
		            </script>
				</div>
				
				
			</div>
		</div>
	</div>
</body>
</html>