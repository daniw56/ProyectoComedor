<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Alumno</title>
    </head>
    <body>
        <h1>Bienvenido al sistema!</h1> 
	
	<p>Entro correctamente al sistema.</p><br><br> 
	 <a href="../../Controlador/cerrar_sesion.php">Salir</a> 
        <?php
        // put your code here
        ?>
    </body>
</html>
