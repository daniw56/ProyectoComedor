<?php
/* A continuación, realizamos la conexión con nuestra base de datos en MySQL */ 
$link = mysqli_connect("localhost","root",""); 
mysqli_select_db($link, "comedor_bd"); 

/* El query valida si el usuario ingresado existe en la base de datos. Se utiliza la función htmlentities para evitar inyecciones SQL. */ 
$myusuario = mysqli_query($link,"select username_us from usuarios_tb where username_us = '".htmlentities($_POST["usuario"])."'"); 
$nmyusuario = mysqli_num_rows($myusuario); 

//Si existe el usuario, validamos también la contraseña ingresada y el estado del usuario... 
if($nmyusuario != 0)
{ 
 
  $myclave = mysqli_query($link,"select permiso_us from usuarios_tb where username_us = '".htmlentities($_POST["usuario"])."' and password_us = '".md5(htmlentities($_POST["clave"]))."'"); 
  $nmyclave = mysqli_num_rows($myclave); 
  //Si el usuario y clave ingresado son correctos (y el usuario está activo en la BD), creamos la sesión del mismo. 
  if($nmyclave != 0)
  {  
        if($myclave==4){         
            header("Location: ../Vista/Alumno/Alumno_Main.php");        
        }          
        if($myclave==1) {  
            header("Location: ../Vista/Admin/Administrador_Main.php");
        }
        if($myclave==2) {  
            header("Location: ../Vista/Profe/Profesor_Main.php");
        }
        if($myclave==3) {  
            header("Location: ../Vista/Dietista/Dietista_Main.php");
        }
        
    }
    else{ 
        echo"<script>alert('La contrase\u00f1a del usuario no es correcta.');</script>"; 
    } 
}
else
{ 
    echo"<script>alert('El usuario no existe.');  </script>"; 
} 
