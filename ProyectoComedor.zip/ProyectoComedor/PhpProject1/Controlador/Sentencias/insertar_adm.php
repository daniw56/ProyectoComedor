<?php
    include("../conexion.php");
    $nombre_adm= $_POST["nombre"];
    $apel1_adm= $_POST["apel1"];
    $apel2_adm= $_POST["apel2"];
    $username_adm= $_POST["username"];
    $pass= $_POST["pass"];
    $permiso= $_POST["permis"];

    $query="INSERT INTO admins_tb VALUES('$nombre_adm','$apel1_adm','$apel2_adm','$username_adm','$pass','$permiso')";
    $resultado= $conexion->query($query);

    if($resultado){
            echo "Operacion exitosa";
    }
    else{
            echo "Error";
    }
