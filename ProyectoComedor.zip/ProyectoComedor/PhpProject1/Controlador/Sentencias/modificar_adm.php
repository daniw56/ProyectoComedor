<?php 
    include("conexion.php");
    $nombre_adm= $_POST["nombre"];
    $apel1_adm= $_POST["apel1"];
    $apel2_adm= $_POST["apel2"];
    $username_adm= $_POST["username"];
    $pass= $_POST["pass"];
    $permiso= $_POST["permis"];


    $query="UPDATE admins_tb SET nombre_adm='$nombre_adm', apel1_adm='$apel1_adm', apel2_adm='$apel2_adm',username_adm='$username_adm',"
            . " password_adm='$pass', permiso_adm='$permiso'";


    $resultado= $conexion->query($query);

    if($resultado){
            echo "Operacion exitosa";
    }
    else{
            echo "No se ha modificado";
    }
