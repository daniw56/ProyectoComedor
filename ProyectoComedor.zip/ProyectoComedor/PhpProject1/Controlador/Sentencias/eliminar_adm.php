<?php
include("../conexion.php");

	$id=$_REQUEST['username_adm'];

	$query="DELETE FROM admin_tb WHERE username_adm='$id'";
	$resultado= $conexion->query($query);

	if($resultado){
		echo("Eliminado correctamente");
	}
	else
	{
		echo "No se ha eliminado";
	}

