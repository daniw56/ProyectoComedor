jQuery(document).on('submit','#formlg', function(event){
	event.preventDefault();

	jQuery.ajax({
		url: 'php/comedor_bd.php',
		type: 'POST',
		dataType: 'json',
		data: $(this).serializable(),
		beforeSend: function(){
			$('.botonlg').val('Comprobando..');
		}
	})
	.done(function(respuesta){
		console.log(respuesta);
		if(!respuesta.error()){
			if(respuesta.tipo == '1'){
				location.href = 'Main_Administrador.html';
			}else if(respuesta.tipo == '4'){
				location.href = 'Main_Alumno.html';
			}else if(respuesta.tipo == '2'){
				location.href = 'Main_Profesor.html';
			}
		}
		else{
			$('.error').slideDown('slow');
			setTimeout(function(){
				$('.error').slideUp('slow');
			},3000);
			$('.botonlg').val('Iniciar Sesión');
		}
	})
	.fail(function(resp) {
		console.log(resp.responseText);
	})
	.always(function() {
		console.log("complete");
	});
});
